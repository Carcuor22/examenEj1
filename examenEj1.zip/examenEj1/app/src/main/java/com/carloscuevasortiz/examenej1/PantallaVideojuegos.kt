package com.carloscuevasortiz.examenej1

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import java.net.URL

/*Crear una pantalla que muestre una lista de videojuegos, cada uno con una imagen,
un nombre y un precio.
Pasos:
1. Define una data class con name, price y imageUrl.
2. Usa LazyColumn para mostrar la lista de productos.
3. Cada elemento de la lista debe mostrar una AsyncImage, un Text para el nombre de
mayor tamaño y otro Text para el precio.
4. La imagen de cada uno se obtendrá de
https://loremflickr.com/400/400/seville?lock=1, cambiando el número para que sean
distintas.
Dependencias:
coil = { group = "io.coil-kt", name = "coil-compose", version.ref = "2.2.2" }*/


fun main() {

    val videojuegos = listOf(
        ListaVideojuegos("Videojuego1", 50, URL("https://loremflickr.com/400/400/seville?lock=1")),
        ListaVideojuegos("Videojuego2", 60, URL("https://loremflickr.com/400/400/seville?lock=2")),
        ListaVideojuegos("Videojuego3", 70, URL("https://loremflickr.com/400/400/seville?lock=3"))
    )




    @Composable
    fun ListaVideojuegos(videojuegos : ListaVideojuegos) {
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(videojuegos) { videojuego ->
                ListaVideojuegos(videojuego)
            }
        }
    }

    @Composable
    fun Videojuego(videojuego: ListaVideojuegos) {
        AsyncImage(
            model = videojuego.imageURL,
            contentDescription = videojuego.name,
            modifier = Modifier.fillMaxWidth()
        )
        Text(text = videojuego.name, style = Material3Theme.typography.titleLarge)
        Text(text = "Precio: $${videojuego.price}")
    }




}





