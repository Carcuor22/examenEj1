package com.carloscuevasortiz.examenej1

import java.net.URL

data class ListaVideojuegos(val name: String, val price : Int, val imageURL: URL){

}




